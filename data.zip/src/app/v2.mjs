// version 1 routes
const v2 = [];

// export default v2
export default v2;
