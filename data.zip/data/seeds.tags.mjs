const seedTags = [
  {
    _id: "664111ca2b58b2527e38bb9a",
    name: "tv",
    slug: "tv",
    creator: "6643ac283233bd867ff1e434",
  },
  {
    _id: "664111ca2b58b2527e38bb9b",
    name: "samsung",
    slug: "samsung",
    creator: "6643ac283233bd867ff1e434",
  },
  {
    _id: "664111ca2b58b2527e38bb9c",
    name: "smartphone",
    slug: "smartphone",
    creator: "6643ac283233bd867ff1e433",
  },
  {
    _id: "664111ca2b58b2527e38bb9d",
    name: "apple",
    slug: "apple",
    creator: "6643ac283233bd867ff1e433",
  },
  {
    _id: "664111ca2b58b2527e38bb9e",
    name: "electronics",
    slug: "electronics",
    creator: "6643ac283233bd867ff1e433",
  },
  {
    _id: "664111ca2b58b2527e38bb9f",
    name: "mobile",
    slug: "mobile",
    creator: "6643ac283233bd867ff1e434",
  },
  {
    _id: "664111ca2b58b2527e38bb91",
    name: "laptop",
    slug: "laptop",
    creator: "6643ac283233bd867ff1e431",
  },
  {
    _id: "664111ca2b58b2527e38bb92",
    name: "intel",
    slug: "intel",
    creator: "6643ac283233bd867ff1e431",
  },
  {
    _id: "664111ca2b58b2527e38bb93",
    name: "watch",
    slug: "watch",
    creator: "6643ac283233bd867ff1e434",
  },
  {
    _id: "664111ca2b58b2527e38bb94",
    name: "leather",
    slug: "leather",
    creator: "6643ac283233bd867ff1e434",
  },
  {
    _id: "664111ca2b58b2527e38bb95",
    name: "backpack",
    slug: "backpack",
    creator: "6643ac283233bd867ff1e434",
  },
  {
    _id: "664111ca2b58b2527e38bb96",
    name: "canvas",
    slug: "canvas",
    creator: "6643ac283233bd867ff1e434",
  },
  {
    _id: "664111ca2b58b2527e38bb97",
    name: "accessories",
    slug: "accessories",
    creator: "6643ac283233bd867ff1e434",
  },
  {
    _id: "664111ca2b58b2527e38bb98",
    name: "sunglasses",
    slug: "sunglasses",
    creator: "6643ac283233bd867ff1e433",
  },
  {
    _id: "664111ca2b58b2527e38bb99",
    name: "metal",
    slug: "metal",
    creator: "6643ac283233bd867ff1e433",
  },
  {
    _id: "664111ca2b58b2527e38bb8a",
    name: "shoes",
    slug: "shoes",
    creator: "6643ac283233bd867ff1e433",
  },
  {
    _id: "664111ca2b58b2527e38bb8b",
    name: "casual",
    slug: "casual",
    creator: "6643ac283233bd867ff1e434",
  },
  {
    _id: "664111ca2b58b2527e38bb8c",
    name: "clothing",
    slug: "clothing",
    creator: "6643ac283233bd867ff1e434",
  },
  {
    _id: "664111ca2b58b2527e38bb8d",
    name: "summer",
    slug: "summer",
    creator: "6643ac283233bd867ff1e433",
  },
  {
    _id: "664111ca2b58b2527e38bb8e",
    name: "cotton",
    slug: "cotton",
    creator: "6643ac283233bd867ff1e433",
  },
];

export default seedTags;
